if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
    console.log("setWebContentsDebuggingEnabled true");
    WebView.setWebContentsDebuggingEnabled(true);
}
